"""Standard-library competition agent."""
