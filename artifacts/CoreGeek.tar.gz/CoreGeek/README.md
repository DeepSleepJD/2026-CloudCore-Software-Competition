# JD v4：生存与任务并行策略

以 `feature/jd` 的 `a7b2b00` 为基础，保留三火箭共用炮位、十二段正面墙和工人经济循环，在 `zk_dev` 开发与交付。原 `feature/jd` 分支未修改。

下载 [比赛提交包 CoreGeek.tar.gz](artifacts/CoreGeek.tar.gz) 的文件本体上传，勿上传 GitHub 整个仓库源码压缩包。详细行为和限制见 [v4 交付说明](docs/v4-delivery.md)，验证见 [冒烟记录](production/qa/smoke-2026-09-18.md)。

## 启动

解压后平台入口为 `CoreGeek/main3.py`：

```bash
cd CoreGeek
python3 main3.py 8080
# 或
bash run.sh 8080
```

将 8080 替换为平台分配的端口。Python 3.10+，仅标准库，监听 `0.0.0.0`。日志输出到标准输出；GET 健康检查显示 `v4-jd`、请求数、最近回合、动作数及异常类型。

提交包仅包含 `main3.py`、`run.sh`、`agent/`、说明与构建信息。仓库中保留的 `zk_agent/`、`config.example.json`、`README-v2.md` 是旧版对照，不是此次部署入口；本版不读取旧配置。

## 本版变化

- 射击首先识别 `targetTeam`，不再为了分数帮助另一队清怪；未知阵营需有接近我方的连续观测或已靠近防线。近距离自保保留例外。
- 接入自进化任务的模型/沙盒异步流程和确认后的解法缓存。任务期间安排工人接炮，夜里任务完成后接班工人继续值守到天亮，避免无人开炮。
- 每天累计新闻，调用比赛模型解析停矿、涨价和宝藏线索；任务外最多三次新闻调用。有防守余款才囤货，缺钱或背包满仍会卖矿。
- 宝藏地点、日期、昼夜、材料齐备且引用新闻原文时才采购和执行；不硬编码这份回放的答案。成功或宝藏已空后停止；材料错误则作废计划，最多两次献祭尝试。
- 根据近期墙体掉血、周围威胁和往日受压情况，预留关键墙维护预算。短时间撑到天亮偏向修墙包，持续承压考虑升级；不盲目给所有墙升级。
- 维修人员先尝试救急用药或近身维修，短途送修会评估人物可承受的伤害；无法承受时撤退。
- 工人保持采矿目标及出售流程；同时购买和在途购买去重，共享金币预算。
- 重复回合请求返回同一决策，显式 null 输入兼容，部署入口沿用 JD。

## 自动化验证

```bash
python -B -m unittest discover -s tests -v
python -B tools/mutation_checks.py
python -B tools/check_replay.py /path/to/replay.json --stride 10
python -B tools/package_submission.py dist/CoreGeek.tar.gz
```

使用风险场景测试、边界组合检查、连续回合小模拟、故意破坏关键行为的变异检查，以及解压后启动真实 HTTP 服务的集成测试。CI 配置为 Linux/Windows × Python 3.10/3.12；Linux 另外运行真实 `bash run.sh` 入口。

任务和新闻测试使用可控的模型回复，不能证明真实 LLM 解题正确率。小模拟不包含完整机器人 AI、对手策略或官方建造区域，回放快照也不计算新策略胜率。部署包不包含原始回放、API 凭据或本地任务缓存。
